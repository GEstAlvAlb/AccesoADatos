import java.awt.EventQueue;

public class Maib {
	public static void main(String[] args) {
		Vista vista = new Vista();
		Marca marca = new Marca(vista);
	}
}
